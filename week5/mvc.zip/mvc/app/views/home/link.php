<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>
    <p>Gửi thông tin thành công!</p>
    <a href="../../home/index" class="btn btn-primary">Thêm thông tin nhân viên</a>
    <br>
    <a href="../../home/query" class="btn btn-primary">Chuyển sang trang truy vấn</a>
</body>
</html>